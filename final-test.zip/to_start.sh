#!/bin/bash

PROJECT_ID="woven-rush-430423-t2"
INSTANCE_NAME="instance-2"
ZONE="us-central1-a"

# Create the VM instance (instance-2)
gcloud compute instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --zone=$ZONE \
    --machine-type=e2-medium \
    --subnet=default \
    --network-tier=PREMIUM \
    --maintenance-policy=MIGRATE \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --tags=http-server,https-server \
    --image=debian-10-buster-v20210721 \
    --image-project=debian-cloud \
    --boot-disk-size=10GB \
    --boot-disk-type=pd-balanced \
    --boot-disk-device-name=$INSTANCE_NAME

# Create firewall rule to open port, if it doesn't exist yet
if ! gcloud compute firewall-rules list --format="value(name)" | grep -q "rule-allow-tcp-5000"; then
    gcloud compute firewall-rules create rule-allow-tcp-5000 --source-ranges 0.0.0.0/0 --target-tags http-server --allow tcp:5000
else
    echo "Firewall rule rule-allow-tcp-5000 already exists."
fi

if ! gcloud compute firewall-rules list --format="value(name)" | grep -q "rule-allow-tcp-5001"; then
    gcloud compute firewall-rules create rule-allow-tcp-5001 --source-ranges 0.0.0.0/0 --target-tags http-server --allow tcp:5001
else
    echo "Firewall rule rule-allow-tcp-5001 already exists."
fi

# Wait for the instance to be up and running (was running into an issue where we were trying to ssh into an instance that wasn't created yet)
sleep 30

# SSH into the instance, load libraries, access the data, and run app
gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="
sudo apt update
sudo apt install python3-pip
sudo apt-get install -y python3-pip wget unzip
sudo pip3 install flask
sudo pip3 install requests
sudo pip3 install urllib3

# Download and unzip the todolist which is hosted on my github repository (afborell)
wget -nc https://raw.githubusercontent.com/afborell/final-test/main/final-test.zip
unzip final-test.zip -d todolist

cd todolist

# Start the backend service
python3 backend_service.py &
"
