backend_api=$(gcloud compute instances list --filter="name=$INSTANCE_NAME" --format="value(EXTERNAL_IP)")

docker build -t aborelli7/cisc-hw4 --build-arg api_ip=${backend_api} . 
docker push aborelli7/cisc-hw4 


gcloud container clusters create hw4 --zone=us-central1-a

kubectl create deployment hw4 --image=aborelli7/cisc-hw4 
kubectl expose deployment hw4 --type=LoadBalancer --port=5000 --target-port=5000

kubectl get services


