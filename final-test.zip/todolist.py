from flask import Flask, render_template, redirect, request, url_for, session, jsonify
import requests
import sqlite3
import hashlib
from google.cloud import translate_v2 as translate
import os

USERS_DB = 'users.db'

app = Flask(__name__)
TODO_API_URL = "http://"+os.environ['backend_api_ip']+":5001"

app.secret_key = os.urandom(24)

translate_client = translate.Client()

def init_users_db():
    with sqlite3.connect(USERS_DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT)')
        db.commit()

@app.route("/")
def home():
    return redirect(url_for('register'))

@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()
        with sqlite3.connect(USERS_DB) as db:
            db.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            db.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()
        with sqlite3.connect(USERS_DB) as db:
            cur = db.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
            user = cur.fetchone()
            if user:
                session['logged_in'] = True
                return redirect(url_for('show_list'))
    return render_template('login.html')

@app.route("/logout")
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route("/show_list")
def show_list():
    resp = requests.get(TODO_API_URL+"/api/items")
    todolist = resp.json()
    return render_template('index.html', todolist=todolist)

@app.route("/add", methods=["POST"])
def add_entry():
    new_item = {
        "what_to_do": request.form["what_to_do"],
        "due_date": request.form["due_date"],
        "status": "open"
    }
    requests.post(TODO_API_URL+"/api/items", json=new_item)
    return redirect(url_for("show_list"))

@app.route("/update/<item>", methods=["POST"])
def update_entry(item):
    updated_status = {
        "status": request.form["status"]
    }
    requests.put(f"{TODO_API_URL}/api/items/{item}", json=updated_status)
    return redirect(url_for("show_list"))

@app.route("/delete/<item>", methods=["POST"])
def delete_entry(item):
    requests.delete(f"{TODO_API_URL}/api/items/{item}")
    return redirect(url_for("show_list"))

@app.route("/mark/<item>", methods=["POST"])
def mark_entry(item):
    updated_status = {
        "status": "completed"
    }
    requests.put(f"{TODO_API_URL}/api/items/{item}", json=updated_status)
    return redirect(url_for("show_list"))

@app.route("/translate", methods=["POST"])
def translate_text():
    text = request.form["text"]
    target_language = "es"
    translation = translate_client.translate(text, target_language=target_language)
    return jsonify(translation)

if __name__ == "__main__":
    init_users_db()
    app.run(host='0.0.0.0', port=5000)
