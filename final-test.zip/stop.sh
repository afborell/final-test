#!/bin/bash

gcloud compute instances stop instance-2
gcloud compute instances delete instance-2

gcloud container clusters delete final --zone us-central1-a